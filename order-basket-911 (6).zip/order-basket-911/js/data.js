const menuItems = [
	{
		id: 1,
		title: "Hamburger",
		price: 80,
		img: "./img/cheeseburger.svg",
	},
	{
		id: 2,
		title: "Coffee",
		price: 100,
		img: "./img/coffee.png",
	},
	{
		id: 3,
		title: "Cola",
		price: 60,
		img: "./img/cola.svg",
	},
	{
		id: 4,
		title: "Tea",
		price: 50,
		img: "./img/tea.svg",
	},
	{
		id: 5,
		title: "Cheeseburger",
		price: 100,
		img: "./img/cheeseburger.svg",
	},
	{
		id: 6,
		title: "Fries",
		price: 40,
		img: "./img/fries.svg",
	},
];

const orderBasket = [];
